<div class="col-md-4 col-sm-6 ml-auto mr-auto">
	<div class="card card-login">
        <div class="card-header ">
        	<img src="<?= Yii::$app->request->baseUrl; ?>theme/img/mercskyafrica.jpg" style="display: block; margin-left: auto; margin-right: auto; width: 50%;"/>
        </div>
        <div class="card-body ">
            <div class="card-body">                
            <div class="alert alert-danger" role="alert">
              <p>You have no SMS bundle to use this service. Please contact the system administrator for more details. </p>
               <button class="btn btn-info btn-block"><i class="fa fa-phone"></i>0727 103934</button>
            </div>
        </div>
    </div>
</div>
</div>