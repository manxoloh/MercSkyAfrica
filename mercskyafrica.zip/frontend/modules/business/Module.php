<?php

namespace frontend\modules\business;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\business\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
