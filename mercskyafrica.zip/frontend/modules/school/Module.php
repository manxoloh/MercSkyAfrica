<?php

namespace frontend\modules\school;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\school\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
