<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;
use common\models\User;

/* @var $this yii\web\View */
/* @var $searchModel common\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Duty Rota';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body ">
                <div class="alert alert-warning" role="alert">
						<h3>Coming Soon</h3>
						<p>This Module is under development</p>
					</div>
            </div>
        </div>
    </div>
</div>
