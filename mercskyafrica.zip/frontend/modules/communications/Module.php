<?php

namespace frontend\modules\communications;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\communications\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
