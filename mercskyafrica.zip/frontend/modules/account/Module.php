<?php

namespace frontend\modules\account;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\account\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
